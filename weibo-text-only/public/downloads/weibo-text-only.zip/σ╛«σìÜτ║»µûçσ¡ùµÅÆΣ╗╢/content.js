console.log("微博仅文字显示脚本已加载");

function hideMultimedia() {
    // 定义头像相关的选择器白名单
    const avatarSelectors = [
        '.woo-avatar-img',
        '[class*="avatar"]',
        '[class*="head"]',
        '.profile_pic',
        '.face',
        '.photo-content',
        '.woo-avatar-panel'
    ].join(',');

    // 使用:not()排除所有头像类型
    const elements = document.querySelectorAll(`
        img:not(${avatarSelectors}), 
        video, 
        [class*="picture"]:not(${avatarSelectors}), 
        [class*="video"], 
        [class*="media"]:not(${avatarSelectors})
    `);

    console.log(`找到 ${elements.length} 个多媒体元素`);

    elements.forEach(el => {
        // 额外检查，确保不是头像或头像容器
        if (!el.closest('[class*="avatar"]') && 
            !el.closest('[class*="head"]') && 
            !el.closest('.profile_pic') && 
            !el.closest('.face') &&
            !el.closest('.photo-content') &&
            !el.closest('.woo-avatar-panel')) {
            el.style.display = 'none';
        }
    });
}

// 初始执行
hideMultimedia();

// 创建一个 MutationObserver 实例来监视 DOM 变化
const observer = new MutationObserver((mutations) => {
    console.log("检测到 DOM 变化");
    hideMultimedia();
});

// 配置 observer：监视子元素和子树的变化
const config = {
    childList: true,
    subtree: true
};

// 开始观察文档体的变化
observer.observe(document.body, config);
console.log("MutationObserver 已启动");

// 拦截并修改网络请求
const originalFetch = window.fetch;
window.fetch = function(...args) {
    if (args[0] && typeof args[0] === 'string') {
        const url = args[0].toLowerCase();
        // 排除头像相关的URL
        if ((url.includes('photo') || url.includes('video') || url.includes('img')) &&
            !url.includes('avatar') && 
            !url.includes('profile') && 
            !url.includes('head')) {
            console.log(`拦截到多媒体请求: ${url}`);
            return Promise.resolve(new Response('', {status: 200, statusText: 'OK'}));
        }
    }
    return originalFetch.apply(this, arguments);
};
console.log("网络请求拦截已设置");

// 添加 XHR 请求拦截
const originalXHROpen = XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open = function(...args) {
    if (args[1] && typeof args[1] === 'string') {
        const url = args[1].toLowerCase();
        // 排除头像相关的URL
        if ((url.includes('photo') || url.includes('video') || url.includes('img')) &&
            !url.includes('avatar') && 
            !url.includes('profile') && 
            !url.includes('head')) {
            args[1] = ',';  // 替换为空数据 URL
        }
    }
    return originalXHROpen.apply(this, args);
};
console.log("XHR请求拦截已设置");